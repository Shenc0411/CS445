close all;
clear;
im = im2double(imread('images/apple_small.jpg'));
subplot(1, 2, 1);
imshow(im);
im_grayscale = rgb2gray(im);
im_grayscale = imgaussfilt(im_grayscale);
im_edge = edge(im_grayscale, 'canny');
subplot(1, 2, 2);
imshow(im_edge);
edge_threshold = 0.2;

[Gmag,Gdir] = imgradient(im_grayscale);
[D, Idx] = bwdist(Gmag > edge_threshold);
figure, imshow(Gmag, []), title('Gradient magnitude');
figure, imagesc(Gdir), title('Gradient direction');
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure
saveas(gcf,'apple_small_gradient_dir','jpg')
[height, width, ~] = size(im);
for i = 1 : height
    for j = 1 : width
        if(Gmag(i, j) < edge_threshold)
            Gdir(i, j) = Gdir(mod(Idx(i, j), height) + 1, min(floor((Idx(i, j) - 1) / height) + 1, width));
        end
    end
end
figure, imagesc(Gdir), title('Gradient direction modified')
set(gca,'XTick',[]) % Remove the ticks in the x axis!
set(gca,'YTick',[]) % Remove the ticks in the y axis
set(gca,'Position',[0 0 1 1]) % Make the axes occupy the hole figure
saveas(gcf,'apple_small_modified_gradient_dir','jpg')